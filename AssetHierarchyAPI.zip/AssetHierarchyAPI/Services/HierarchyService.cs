﻿using System.Text.Json;
using AssetHierarchyAPI.Models;

namespace AssetHierarchyAPI.Services
{
    public class HierarchyService
    {
        private readonly string filePath = "Data/hierarchy.json";

        public AssetNode LoadHierarchy()
        {
            var json = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<AssetNode>(json);
        }

        public void SaveHierarchy(AssetNode root)
        {
            var json = JsonSerializer.Serialize(root, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }

        public void AddNode(int parentId, AssetNode newNode)
        {
            var root = LoadHierarchy();
            var parent = FindNode(root, parentId);
            if (parent != null)
            {
                parent.Children.Add(newNode);
                SaveHierarchy(root);
            }
        }

        public void RemoveNode(int nodeId)
        {
            var root = LoadHierarchy();
            if (root.Id == nodeId)
                throw new InvalidOperationException("Cannot remove root node");

            RemoveNodeRecursive(root, nodeId);
            SaveHierarchy(root);
        }

        private bool RemoveNodeRecursive(AssetNode parent, int nodeId)
        {
            foreach (var child in parent.Children.ToList())
            {
                if (child.Id == nodeId)
                {
                    parent.Children.Remove(child);
                    return true;
                }
                if (RemoveNodeRecursive(child, nodeId))
                    return true;
            }
            return false;
        }

        private AssetNode FindNode(AssetNode current, int id)
        {
            if (current.Id == id)
                return current;

            foreach (var child in current.Children)
            {
                var found = FindNode(child, id);
                if (found != null)
                    return found;
            }

            return null;
        }
    }
}
